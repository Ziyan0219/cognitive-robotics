import sys
import os
sys.path.append(os.path.abspath("../vex-aim-tools"))
import numpy as np
from aim_fsm.kine import Kinematics
from aim_fsm.geometry import translation_part
from aim_fsm.aim_kin import AIMKinematics


class FakeRobot:
    def __init__(self):
        self.pose = type('Pose', (object,), {'x': 0, 'y': 0, 'theta': 0})
        self.camera = type('Camera', (object,), {'resolution': (640, 480), 'center': (320, 240), 'focal_length': (500, 500)})

robot = FakeRobot()
kine = AIMKinematics(robot)

def calculate_camera_origin_and_fruit_fly_base_coords(kine):
    camera_to_base_transform = kine.joint_to_base('camera')

    camera_origin_base = translation_part(camera_to_base_transform).flatten()

    fruit_fly_camera_coords = np.array([0, 0, 20, 1])

    fruit_fly_base_coords = camera_to_base_transform @ fruit_fly_camera_coords

    print("Camera origin in base frame:", camera_origin_base[:3])
    print("Fruit fly coordinates in base frame:", fruit_fly_base_coords[:3])

    return camera_origin_base[:3], fruit_fly_base_coords[:3]





if __name__ == "__main__":
    camera_origin_base, fruit_fly_base_coords = calculate_camera_origin_and_fruit_fly_base_coords(kine)

