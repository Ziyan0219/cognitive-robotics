from .worldmap import *

# Disabled ArUco ids: 17 and 37.  Don't use them.

def make_walls():

    # side +1 measures x from the left edge rightward
    # side -1 measures x from the right edge leftward

    w1 = WallSpec(length=300, height=190,
                  marker_specs = { 14 : {'side': +1, 'x':  28, 'y': 29},
                                   18 : {'side': +1, 'x':  80, 'y': 28},
                                   19 : {'side': +1, 'x': 213, 'y': 28},
                                   20 : {'side': +1, 'x': 268, 'y': 28},

                                   16 : {'side': -1, 'x': 272, 'y': 29},
                                   15 : {'side': -1, 'x': 218, 'y': 30},
                                   13 : {'side': -1, 'x':  85, 'y': 28},
                                  12 : {'side': -1, 'x':  33, 'y': 28}, },
                  doorways = { 'd1' : {'x': 150, 'width': 75, 'height': 115} }
                  )


make_walls()
