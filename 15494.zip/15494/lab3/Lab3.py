from aim_fsm import *
from aim_fsm.particle import *

class Lab3(StateMachineProgram):
    def __init__(self):
        landmarks = {'ArucoMarker-1': Pose(-25, 160, 0, -pi/2),
                     'ArucoMarker-2': Pose( 25, 160, 0, -pi/2),
                     'ArucoMarker-3': Pose(160,  25, 0,  pi),
                     'ArucoMarker-4': Pose(160, -25, 0,  pi)}
        super().__init__(landmarks = landmarks,
                         sensor_model = ArucoDistanceSensorModel,
                         #sensor_model = ArucoBearingSensorModel,
                         #sensor_model = ArucoCombinedSensorModel,
                         speech = False,
                         launch_particle_viewer = True)